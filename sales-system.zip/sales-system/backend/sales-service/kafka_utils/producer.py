from kafka import KafkaProducer
import json
import logging

logging.basicConfig(level=logging.INFO)

producer = KafkaProducer(
    bootstrap_servers=["kafka:9092"],
    value_serializer=lambda v: json.dumps(v).encode("utf-8")
)

def publish_sale_created_event(event_data: dict):
    producer.send("sales_created", event_data)
    producer.flush()
    logging.info(f"📤 Event sent to Kafka: {event_data}")
