from fastapi import FastAPI
from kafka_utils.producer import publish_sale_created_event

app = FastAPI(title="Sales Service")

@app.get("/")
def health():
    return {"status": "sales-service running"}

@app.post("/sales")
def create_sale(sale: dict):
    event = {
        "event": "SALE_CREATED",
        "sale_id": sale.get("sale_id"),
        "product_code": sale.get("product_code"),
        "quantity": sale.get("quantity"),
        "sale_date": sale.get("sale_date"),
        "created_by": sale.get("created_by", "system")
    }
    publish_sale_created_event(event)
    return {"status": "ok", "published_event": event}
