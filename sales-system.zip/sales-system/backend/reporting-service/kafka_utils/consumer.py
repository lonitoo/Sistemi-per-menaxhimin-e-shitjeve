from kafka import KafkaConsumer
import json
import time
import logging

logging.basicConfig(level=logging.INFO)


def safe_json_deserializer(message):
    try:
        return json.loads(message.decode("utf-8"))
    except Exception:
        return {
            "raw_message": message.decode("utf-8", errors="replace")
        }


def start_consumer():
    logging.info("⏳ Waiting for Kafka to be ready...")
    time.sleep(10)  

    consumer = KafkaConsumer(
        "sales_created",
        bootstrap_servers=["kafka:9092"],
        auto_offset_reset="earliest",
        enable_auto_commit=True,
        group_id="reporting-service",
        value_deserializer=safe_json_deserializer
    )

    logging.info("✅ Consumer started. Listening on topic: sales_created")

    for message in consumer:
        logging.info(f"📩 Event received: {message.value}")
