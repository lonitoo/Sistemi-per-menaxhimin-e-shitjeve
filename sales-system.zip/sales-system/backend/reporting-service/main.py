from fastapi import FastAPI
import threading
import logging

from kafka_utils.consumer import start_consumer

logging.basicConfig(level=logging.INFO)

app = FastAPI(title="Reporting Service")

@app.get("/")
def health():
    return {"status": "reporting-service running"}

@app.on_event("startup")
def startup_event():
    logging.info("🚀 Starting Kafka consumer thread...")
    t = threading.Thread(target=start_consumer, daemon=True)
    t.start()
